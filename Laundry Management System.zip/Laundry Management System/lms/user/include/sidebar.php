<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="laundryrequest.php" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Laundry Request</span>
        </a>
         <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="laundryrequest.php">Laundry Request</a>
        
          
          
        </div>
      </li>
   
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Request Status</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        
        <a class="dropdown-item" href="new-request.php">New Request</a>
          <a class="dropdown-item" href="accept-request.php">Accept Request</a>
           <a class="dropdown-item" href="inprocess-request.php">In Process Request</a>
            <a class="dropdown-item" href="finish-request.php">Finish Request</a>
          
          
        </div>
      </li>
    </ul>
